package com.timtom;

public class Main {

    public static void main(String[] args) {
	    App app = new App();
    }


}
