package com.timtom.exeception;

public class NoModelFoundException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7019872490379417093L;

	public NoModelFoundException()
	{
		// TODO Auto-generated constructor stub
	}

	public NoModelFoundException(String arg0)
	{
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NoModelFoundException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NoModelFoundException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoModelFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
